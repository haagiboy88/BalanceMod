Balance Mod for The Binding of Isaac: Rebirth
-----------------------------------------------
Download here: https://github.com/Zamiell/BalanceMod/releases
Information here: https://medium.com/@Zamiel/the-balance-mod-6ed62cc50de1
